# Guia Ceia Natal - Tarefas

## Fase 1: Estrutura e Design
- [ ] Criar página inicial (landing page) com design natalino
- [ ] Implementar hero section com imagem da ceia
- [ ] Criar seção de problemas/benefícios
- [ ] Criar seção de como funciona
- [ ] Criar seção de características do guia
- [ ] Criar seção de bônus
- [ ] Criar seção de garantia
- [ ] Criar seção de preços
- [ ] Criar seção de FAQ
- [ ] Implementar footer

## Fase 2: Funcionalidades
- [ ] Integrar contador regressivo
- [ ] Implementar scroll suave para seção de compra
- [ ] Criar página de checkout
- [ ] Integrar sistema de pagamento (Stripe)
- [ ] Criar página de obrigado após compra
- [ ] Implementar entrega automática do PDF

## Fase 3: Backend
- [ ] Criar tabela de vendas no banco de dados
- [ ] Criar procedimento tRPC para processar vendas
- [ ] Implementar validação de pagamento
- [ ] Criar sistema de notificação para o dono

## Fase 4: Testes e Deploy
- [ ] Testar fluxo de compra completo
- [ ] Testar responsividade em mobile
- [ ] Testar integração de pagamento
- [ ] Fazer checkpoint do projeto
- [ ] Publicar site permanente
