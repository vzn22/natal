import { Button } from "@/components/ui/button";
import { ChevronDown } from "lucide-react";
import { useEffect, useState } from "react";

export default function Home() {
  const [timeLeft, setTimeLeft] = useState({ days: 0, hours: 0, minutes: 0, seconds: 0 });

  useEffect(() => {
    const timer = setInterval(() => {
      const now = new Date();
      const christmas = new Date(now.getFullYear(), 11, 25);
      if (now > christmas) {
        christmas.setFullYear(christmas.getFullYear() + 1);
      }
      
      const diff = christmas.getTime() - now.getTime();
      setTimeLeft({
        days: Math.floor(diff / (1000 * 60 * 60 * 24)),
        hours: Math.floor((diff / (1000 * 60 * 60)) % 24),
        minutes: Math.floor((diff / 1000 / 60) % 60),
        seconds: Math.floor((diff / 1000) % 60),
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    element?.scrollIntoView({ behavior: "smooth" });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Navigation */}
      <nav className="sticky top-0 z-50 bg-white border-b border-gray-200 shadow-sm">
        <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
          <div className="text-2xl font-bold text-red-700">🎄 Ceia Perfeita</div>
          <button
            onClick={() => scrollToSection("compra")}
            className="bg-red-700 text-white px-6 py-2 rounded-lg font-semibold hover:bg-red-800 transition"
          >
            Comprar Agora
          </button>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="bg-gradient-to-r from-red-700 via-red-600 to-green-700 text-white py-20 px-4">
        <div className="max-w-6xl mx-auto grid md:grid-cols-2 gap-12 items-center">
          <div>
            <h1 className="text-5xl md:text-6xl font-bold mb-6 leading-tight">
              Guia Absoluto da Ceia de Natal Perfeita
            </h1>
            <p className="text-xl mb-8 text-red-50 leading-relaxed">
              Aprenda a preparar uma ceia memorável com planejamento profissional, receitas detalhadas e dicas de ouro. Transforme sua noite de Natal em um momento inesquecível.
            </p>
            <button
              onClick={() => scrollToSection("compra")}
              className="bg-white text-red-700 px-8 py-4 rounded-lg font-bold text-lg hover:bg-gray-100 transition inline-block"
            >
              Começar Agora →
            </button>
          </div>
          <div className="hidden md:block">
            <div className="bg-white rounded-lg p-8 shadow-2xl">
              <div className="bg-gradient-to-br from-red-100 to-green-100 rounded-lg h-80 flex items-center justify-center text-6xl">
                🍗🎄🍰
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Countdown Timer */}
      <section className="bg-red-50 py-12 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-3xl font-bold text-red-700 mb-8">⏰ Faltam para o Natal:</h2>
          <div className="grid grid-cols-4 gap-4 md:gap-8">
            {[
              { label: "Dias", value: timeLeft.days },
              { label: "Horas", value: timeLeft.hours },
              { label: "Minutos", value: timeLeft.minutes },
              { label: "Segundos", value: timeLeft.seconds },
            ].map((item) => (
              <div key={item.label} className="bg-white rounded-lg p-4 md:p-6 shadow-md">
                <div className="text-3xl md:text-4xl font-bold text-red-700">
                  {String(item.value).padStart(2, "0")}
                </div>
                <div className="text-sm md:text-base text-gray-600 mt-2">{item.label}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Problems Section */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-red-700 mb-12">Os Desafios da Ceia Perfeita</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { icon: "😰", title: "Falta de Planejamento", desc: "Não sabe por onde começar ou deixa tudo para última hora" },
              { icon: "🍖", title: "Carnes Ressecadas", desc: "Carnes duras e sem sabor que decepcionam os convidados" },
              { icon: "⏱️", title: "Falta de Tempo", desc: "Tudo pronto ao mesmo tempo é quase impossível" },
            ].map((item, i) => (
              <div key={i} className="bg-red-50 rounded-lg p-8 border-l-4 border-red-700">
                <div className="text-5xl mb-4">{item.icon}</div>
                <h3 className="text-xl font-bold text-red-700 mb-3">{item.title}</h3>
                <p className="text-gray-700 leading-relaxed">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 px-4 bg-green-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-green-700 mb-12">Como Funciona</h2>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { num: "1", title: "Receba o Guia", desc: "Acesso imediato ao PDF completo" },
              { num: "2", title: "Estude", desc: "Leia todas as receitas e dicas" },
              { num: "3", title: "Prepare", desc: "Siga o cronograma passo a passo" },
              { num: "4", title: "Celebre", desc: "Ceia perfeita com sua família" },
            ].map((item, i) => (
              <div key={i} className="text-center">
                <div className="bg-green-700 text-white rounded-full w-16 h-16 flex items-center justify-center text-3xl font-bold mx-auto mb-4">
                  {item.num}
                </div>
                <h3 className="text-lg font-bold text-green-700 mb-2">{item.title}</h3>
                <p className="text-gray-700">{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Features */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-red-700 mb-12">O Que Você Vai Receber</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              "✅ 50+ Receitas Detalhadas",
              "✅ Cronograma Completo",
              "✅ Lista de Compras",
              "✅ Técnicas Profissionais",
              "✅ Dicas de Decoração",
              "✅ Etiqueta à Mesa",
            ].map((feature, i) => (
              <div key={i} className="flex items-center gap-4 text-lg">
                <span className="text-2xl">🎁</span>
                <span className="text-gray-800 font-semibold">{feature}</span>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Bonuses */}
      <section className="py-16 px-4 bg-yellow-50">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-yellow-700 mb-12">🎉 Bônus Exclusivos</h2>
          <div className="grid md:grid-cols-3 gap-8">
            {[
              { title: "Receitas Bônus", desc: "6 receitas especiais extras" },
              { title: "Checklist Prático", desc: "3 checklists para não esquecer nada" },
              { title: "Dicas de Ouro", desc: "10 dicas profissionais exclusivas" },
            ].map((bonus, i) => (
              <div key={i} className="bg-white rounded-lg p-8 border-2 border-yellow-400 shadow-lg">
                <h3 className="text-xl font-bold text-yellow-700 mb-3">{bonus.title}</h3>
                <p className="text-gray-700">{bonus.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Guarantee */}
      <section className="py-16 px-4 bg-green-100">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-4xl font-bold text-green-700 mb-6">✨ Garantia de 7 Dias</h2>
          <p className="text-xl text-gray-800 max-w-2xl mx-auto leading-relaxed">
            Se não ficar satisfeito com o guia nos primeiros 7 dias, devolvemos 100% do seu dinheiro. Sem perguntas. Sem complicações.
          </p>
        </div>
      </section>

      {/* Pricing & Purchase */}
      <section id="compra" className="py-20 px-4 bg-gradient-to-r from-red-700 to-green-700 text-white">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center mb-12">Oferta Especial de Natal</h2>
          <div className="bg-white text-gray-900 rounded-lg p-12 shadow-2xl">
            <div className="text-center mb-8">
              <p className="text-gray-600 line-through text-xl mb-2">Valor Normal: R$ 197,00</p>
              <p className="text-5xl font-bold text-red-700 mb-2">R$ 97,00</p>
              <p className="text-green-700 font-semibold">50% de Desconto por Tempo Limitado</p>
            </div>
            <button
              onClick={() => alert("Sistema de pagamento será integrado em breve!")}
              className="w-full bg-gradient-to-r from-red-700 to-green-700 text-white py-4 rounded-lg font-bold text-xl hover:shadow-lg transition"
            >
              Comprar Agora - R$ 97,00
            </button>
            <p className="text-center text-gray-600 mt-6 text-sm">
              ✓ Acesso imediato ao PDF<br/>
              ✓ Garantia de 7 dias<br/>
              ✓ Suporte por email
            </p>
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-16 px-4 bg-white">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-4xl font-bold text-center text-red-700 mb-12">Perguntas Frequentes</h2>
          <div className="space-y-6">
            {[
              { q: "Como recebo o guia?", a: "Após a compra, você recebe um link para baixar o PDF imediatamente." },
              { q: "Posso imprimir o guia?", a: "Sim! Você pode imprimir quantas vezes quiser." },
              { q: "E se não gostar?", a: "Garantia de 7 dias com reembolso total, sem perguntas." },
              { q: "Preciso de experiência culinária?", a: "Não! O guia é feito para iniciantes e experientes." },
              { q: "Quanto tempo leva para preparar?", a: "Com o cronograma, você consegue em 3 dias de preparação." },
              { q: "Funciona para quantas pessoas?", a: "O guia cobre desde 5 até 50+ pessoas." },
            ].map((faq, i) => (
              <div key={i} className="border-l-4 border-red-700 bg-red-50 p-6 rounded">
                <h3 className="font-bold text-red-700 text-lg mb-2">{faq.q}</h3>
                <p className="text-gray-700 leading-relaxed">{faq.a}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gradient-to-r from-red-700 to-green-700 text-white py-12 px-4">
        <div className="max-w-6xl mx-auto text-center">
          <p className="text-lg mb-4">🎄 Guia Absoluto da Ceia de Natal Perfeita 🎄</p>
          <p className="text-red-100 mb-6">"O Natal é comida... mas também é memória, união e amor."</p>
          <p className="text-sm text-red-100">© 2024 Todos os direitos reservados</p>
        </div>
      </footer>
    </div>
  );
}
